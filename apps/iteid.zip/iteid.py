#!/usr/bin/env python3
"""
ITE Image Downloader

A single-file desktop app: paste a web page address, click Download, and every
image on that page is saved to a folder.

Uses only the Python standard library (no pip installs needed).
Run:    python itesteye_image_downloader.py
Build:  see build_exe.bat to make a single .exe for Windows.
"""

import mimetypes
import os
import queue
import re
import subprocess
import sys
import threading
import tkinter as tk
import webbrowser
from html.parser import HTMLParser
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from urllib.parse import unquote, urljoin, urlparse
from urllib.request import Request, urlopen

APP_TITLE = "ITE Image Downloader"
APP_NAME = "iTestEye Image Downloader"
APP_VERSION = "1.0"
ICON_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAOSElEQVR42u2ae5BV1ZXGf2vvc87t2327oaFBxKYBQYw8JqNx1KnI"
    "S6MljBpTDkSDY0kcoylrykpGp3TGEVAnmsoYK5ZljVM6Gp9BiKITRPGJilFjIkGRp4CNNHQ3NtCP+zrn7DV/3NtNg5cGoYmt46ra"
    "VV19zz13r2+t9a3H3vC1fC1fy9fy/1jkCD//RYoezEO251eowBSPKSNg2TL9Upl2zhzDlLn20Pc+4wm7HweQPr4+66gldenJpWc8"
    "YVkwM+Zflxxtqgb/UDU+U2I9CnUG0T4eBqKIKGKbVcwrmk3/D/Mm1nfpdEAAig/aea+fp4ny+wiSg4lC0PjLRQBiwAsgzO4k0361"
    "mzvp8VIgSEnlb3nrDA2CF3DOEOVDa4yJ1cmXhQQEsGLUqXNqfB8/QHKZC+IbT3t6XxCkO2Yo8Mvfl5kMq/CTIwmzkYKnuRgJLEYK"
    "1NpXPaFzbw7o3LOgMV5gicMmF2aPZ96U3YUHC/b09rDmqxaZGtlbfz9dy1IjybTGIsYzqlx/5nDOGzOAyCnSxwNBAc/Aixt3cfOr"
    "9YSIlTgfabLfYKN6oUPuZ+4rHhDtDUBRnOpEEaPWWg0zIZefMpRbJteyO68YkZ5/Wt0exxL5wnwlVuWUo8vZkYm4c1k9frlPjKrC"
    "6cD93Z/1SrBHfygyvcLJQyvJOaU9H+MZsx/dYzA+6tmC7g4IXeH/Yv7yADhHwlpOPjpFIW5VCjWN9AdgXLPuHwDRvbgudAXLF1bJ"
    "YglN+Jj0LkzDe0huF5qqIx58ElgPwugvDoIW9xs6PWB16B1W7asO9T38dQsJVtyJSTcWKEg84oETyJ16M3HNOOQLAOFg6/ZD35U6"
    "NPDw1/+Wsjd+WrB8UIUG/VE/hd2xguRLszG7NoNnu/FD3xJzyFxrLCa9i2DFnahfCTZRiPni0sQAJNNEYuVdqOm7mcMcsvU9wTSv"
    "wKS37VF+r3QSon4K0/QuJt0KxjvYBu3L4AHFTJffCao9PiRxFqKOQkDqVyYEBBxoajhqvP0zkMZoohpNDCgAJV8VAMQgUUw8aAJu"
    "4DeR/G4wwZ6OVATER/K7iYafi5YlwEV9sog+jCygqPXJnToPLRuIZJtBowIXxHkk3UBUexb58f+IhF9MQXSEOcAgYURcM5b0OfOJ"
    "jv1ewdW9JJoaRv7E68hO/S/UlhW6kz7aQ3iH9e0iCFo1kszkOwtsH3agZQPRsgDyCrFDiz2EfOUAKIJAFBU4L6iCRBWoItkQjMGz"
    "BtVCg8JXEoBOEDqbIlcwdYRhSNJy1bObcAr3/t1IGjtivD5WFHm9+zoBKTRQR1VY7nh7O//9VgMAJx2d4ooTB9GUjvH7EAi9Ts2h"
    "UwaXW36zqoXrlmzEL7N4CctPnv2IZfVtVJdZIqdfTQAipwxIWpbVt3HFonVYT4oJQMjFjsueWsfWtjzlvuHzYqB7sm/fBCB2SmXC"
    "snZHlh8sWEMmdogpEKBTxQ8sn7RkuWzR+sIPy8FXxgr4RhABa3oXhF4BwKlS5htaMiEzF6yhqT2P71tct53GTgmSHss37OQnSzfR"
    "v8zgDsINIqcMThp++VYDlzy5lorA4FvpNRDM4SsPnhGcKhf/dh3rGjvwEx5xCeUipwQVPg+83cCv3tnOoApbamqzN59UWO59r5mf"
    "Lavn+febmblwHWHsiFWJnBJ3X8rnDq3DygKdY+hy3zDrqfW8uWEnQYXfI8nFTvHKPG54fhPfqEly1sh+tGQ+mx7DWBmcsixcs5Or"
    "nlwLQO2QCsotZKOYuqqgxDAU2vKOdKioFvZnpec59mEB4JxSU2655vnNPLWi8YDKd4EmQoxy+aL1vHzZBIZVBaRDhy1WjGFcsPzz"
    "H+3mokdWMX5oiusn1jJrQg0ALZmIN7e0sbUtTyZ0lAeGYZUBowcmGZj06J8wXcaJsxEmCJD9cM4hA9CZ629/cxv3LP/koJTvzhme"
    "b2hqzXHpU+tYesm4YhgVwmRQheW1+jZmzF/D3DPrmDO1DoCHVzbz0J+beXd7B7vSIURagFQErDCwwue0YyqZNaGGvx87kEsnDGT1"
    "2SO4/bUt4CuekcJhwOEC0Jnrf71yBzcu3YhfVjrmD5Q1gjKPP23ezdVLNvLQd0fTlI6pSVr+uK2D2c+sZ+HMMUwfXc2Ta1q4/oXN"
    "rG9MF9KHb7C+wQTSNWdxqnyaiVi8+lMWf7iD24+p5OdnDee2M+qYOKySixdvozXtxFDszQ6VBCOnDExaXtjUyo+f2YD1LE4ObdjT"
    "SYrz/7Sdn72xldqUZV1LltnPbOCxC45j+uhqfvzsRi58dDXrW7IEFT5+0sMa6X4W3vW3NYKf9PDLfVZu72Dar1dx7QsfM/24ahZf"
    "PJoBCZMHmDFjxqF5QOSUqoTl/aYMlyxcS+gU65m90t2h1A9emcfNy+qprQy4+93t/PyMYXx7WCXfe2Iti1Y0EVQGXeHRqXEcOoi6"
    "2dK3GE+6PNELLALc8Uo9jR15efiC41hx9Yl1dTfAE4WKSkREvc+T61OBpbEj5PsL1tCSDvET9nO7filSVMDzDFfMX82c6cdy/pgB"
    "XLVkE4tWNJGoCgjjPb9hBOLIMX5IBX8zNEWsihVh+ZY21u9IFw1S2K8AiaqAR97Zbmr7JeLbptadlo2ia0XkP1XVArF3sLneN4Z8"
    "7Lho4Ro2Nqfxk95hK99dqSgfc8KIfsydVMvTa1u4982tBJV7K194VohyjnPHVHNbkRwBrnp2I+sa2jHdCjAFolgJUgG3v1JvzhlV"
    "7SbXVc5rSOsCoF5VjTkYCwGUecLsZzbwh827CXpReYppUSPHTRNriVW5ZulmxOuhXxDIhI6oeGYZOSUXlR66dnoYxsjVSzY6oPzo"
    "JNdJ4Xj8wAA4VRIGrlm6icXvNxOU+73azRmBMHQcNSDJjLEDmL/qUz5uTOMFtkduMVKoQDtXTwfXsSp+wrJqS6t9blObAhe/t2ln"
    "fxGJzIHMX1Puc9cfGnnwrQbKUj5OFSP02vKMwUSOaaP6Y0W4770m5AjMCwQQMXLvuw0OGDCmtv/k0lmgOMBzTpGE5YEVjby0ficY"
    "IZuNe32+HxkHuZizju1HLna809COBqUbpX2ugvX4uZbwZA0Mb2xpU0DLPSYBT5ciwVaQAgyxI3TK8iv+ipZMvOeSXK9aRohix9QR"
    "lfy5MU1HNsL65jPdnlNFpDBf0B74yhWX6t4XOpyCMcKO9rxsySPDAsaW9ACxvAn6T+qciGdZua2dlY0Zpo3uT+ToMdYOp6eoDCyb"
    "d+UgVmwgRN0QMEZIGkM6dJgDeIApIlHhW7KxFu6FFMUKuNDJ5paQYUP8o/axZ/GS1NxVFcZrXYufGEqYi51iCWP8Mr9Amdq7cRmr"
    "ElhD009PZtHaFmb9Zs1efYUAxin3nDeK74zoRzpyWKA66TG4wi9EpMD29pDd2YhIIRUYnlq7k2uf24R40pVNrBHCjtAt+dG3zDl1"
    "yQ9FZHw3EhRlwQLDvPHtovZKrAfWs9YQ+mWeC51zuci5XNy7K3Tq0lHscpHTVGBgn7JaBGJgzsv1RKqMrUlyfE2SwRV+1+cAQ1I+"
    "x9ckGTcoya5czK2v1qP7vEtVwYimEj5AFtC9s8DMmTEznrDxTaf+jkzrLIzXpuX9/dgrM9YPen0ZPzCeHxhVz2ztiOTY6jKwe5fW"
    "TsFYQ0NrnskPfMDGXbmusnzfMh1gVXOGMx78gE8zEcbuzSWueIXs2GoPYHvpLLCgAIK7aeJj3PLG24JeKeqmahwPBtfrU2RrjJAN"
    "9cOmjuoLjq8uryz3aMvFYo10Wc8V83jD7hznPbaaZbPHU5P0CuBIIYw8I3zSlufcx1bTko4+U6YbgShSjqr0dWiAAqv23wwVQeDf"
    "T/9I4V8U4FfrErT4Apt7FYDvjhvkLVjVHE2qrfxBYM39px2Til9cu9OafarNzvb5w+0dnP/4Gl78h7EkfUPkCsrvzEZMf3Q1m1sy"
    "BGXeZzzEiCBhzOThVQJIay5aduCkNmeOgSmGeVNjjtD1hs6cvbW1tWZoZeXGJ9ftSl340Pv4FYGUKrc9K+TbQ6aPG8jT3/8G1gjZ"
    "yHHOo6t5bcMugnKvZKVqjRCmI/fSj/5azhhWsWP5jh2jTh80qO1zJLUjd0v8FcVOFYlU9T7g8jH3rIg2NKc9z7clzxR9K+TaQi45"
    "ZQj3TBvJrEUb+N+VzQQpnyjej/LZmJPqKqM/Xj7BA+4QkWtV1esTZ1SqagDdsjs7ali/sg9e2tzqfef+lSZI+hKrlnS9zpgeMyjJ"
    "uqY0nl+6d5DOfiMX69tXflNPGZpqr0+nT6grL99GX7m1ICIOMHX9kxvCOJ535ogqe92Uuijfnsezpae6TsHzpKi82a/ynhHC9pD/"
    "OHtEdMrQlAljrh9eUdFQoAVxfeaUUlWlc1P5OF7sGzPt0qc3hA+/vc33Uz6IlGzBjZQ+C7BGUFWijpCrT68N75420g8d8wMrF6mq"
    "FZH4CFT2vQKC7ICKascSa/j2DS/Vh7cv2+JhRPyE3dPYaClPoqv+D7MRCHrrmcOjf5tY64exW+pbcz4QFlq+wnX5PndpQ1WNiLhm"
    "1coBjkeM4fyXP27jn5/bGK34pM2CCL7B2MJ9YBG6zh9drBDGAHrq8H7xndNHeX87tJzI8fgn9Zt/OHLkyKwWZ4Hdw4S+CgJANoqu"
    "S1h7I1D1uw2tPPjetviNLW3a2JYXIiddJyC+0aGVCZ1UlzKzv3WMOXtECqAlG8ZzkoF3d6eHdVe+T4uqSjEkaMxkRqnqXaraqEX5"
    "OKP6+ra8Lv04o8u3h7olp91lq6r+4tO0DusEtPNdpYiyrwPRRVgf1O8aMHJwxaTyhHc6cAIwBAiAHLAN+LAj4rUPdvP6aTXSuu/3"
    "v7RStKDXQzFZ6jtesb7oUf4P/IBsTZ7eH9AAAAAASUVORK5CYII="
)
WEBSITE_URL = "https://itesteye.com"
CONTACT_EMAIL = "info@itesteye.com"
LOGO_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAPAAAABTCAYAAACh3YrSAAA4K0lEQVR42u2deZxcVZn3v88599bS3ekEJIAoiqioBDfIC2QDMi44"
    "4jZq9+uu44w6OjqMMwOoJFRXuiO4jeM6A6+jMyrqdM8i4q5jomRpMCgqQcUNBYIECEkvtdx7z3neP86t6iWdvYMS+vlYH0x3V91b"
    "95zfefbfIzyQMjhoGQKGet1uv6tsOhprHoPxjzKYo0AfjiIAqjwS0SKIZ07m5LCLGlSaItwBgKAgd3n8/XjzO5z/DdWlO3Z7W8+g"
    "pQfonWF/HyaRw36FSsWwaJHs9qUGNjzNqH26CmeI8n9AH40wD0wHUQxxceL2vAN0bl/NyQMoAsa2AA1pE7IU8DWUUZDfqvB9UW70"
    "4n7IquU37aastm5VqlX/4ARwpWJY1Cf0Shu40drhFU7sc8RnL0TksZS6SkB4MN6BOvAewOev1vOTuQ01J38ADE/WGgYwGANiA7ij"
    "OPymMdZA9Vdqomusuq9nl5593QSQ1bK177ABefaBoSoMYdrAvWL4kQbzMlL3Cqx9OsUOyJIAWvUZqoIgKBLuRh4Yy2BO5uQgdnfr"
    "fwiKoogoYiKiGKICNGvg3A+J7ec8/gu84+w72kDuwSOif6wAFirrLNWVWdDA150shcLbRMzLKJSOx2WQ1hXFTwBWZBr4w5cLX1JR"
    "zf+/6pwFPScPtAUNIkHB5EpFVfL9ufu+bQMaQ1wWbARJ4/eq/guaJB+huuLXARfrIqorZ80nnB0AVyqGvr5wGlW+cawUj7pY0L+k"
    "0DGfpA4uc0G/iky5ZgBs61SyGCuICX9mcjNFTP6aU8xz8sAqWtSHl3e5i6f5vzMFcTmgzTRAtxSOYiNLoQxJbZcin9Dm/e+lev52"
    "VIW+PpkNs/rQEdEzaFtRZXP58Osh7qNQPJHGOHjndvuCqoqIA7WYSCiUwETQGAOX7QKpgd6vIttQvQPkLkF3AvVpPsmczMlhEgP4"
    "sirzEXMC6ImCPgLlKJAyNppPqZNgVTbAZWFPq9rd9jp4jLWUOiFp3g5pn3/n2Z+cjp0/AIBVqKwPJnPle6dIFH9YSp3nkzUhS3cH"
    "LhpOGxMZih2QNMCl9yqsE+SH4vzNLsqGSY7exS23uEP9YnMyJ7MqPYOWU0+1FHbMty5eokYWKf50Qf6EKD6auBT8X5/lWlXMbkCO"
    "YktURBvj39As/Ruq59waTOrzHBycb3xwAJ7wC5T+4VcbYz9IofgwGmMepvu26kGUuGgxFhq1exSuMcZ/xdniOt6xeNdeTfNFi4St"
    "C/PPO29uI83JAyDrw38W3aP7TAV98IcLbK3xJ97pi0T0AkpdR+M9pA0HKjMAWSl1GZLmfd67t7P67M/k/jUHE+A6cABX1FAVzxuv"
    "jOXEp7xHCqW347OgdUXs1JsVT1wIwM2Sm1A+4ZN0iOqy7VMOgzfdGPHMX3t6ejwT2J8zl+fkjy6shSoMDRm+fbLhyjOyKaCrXH+8"
    "ifVliLyGuPj0AOSmA53uRjqi2GIiNGl8UG//8SVc9aa0ja3DBuCWzX7RhnlmQfx5Sl0XUB/xqBfETL1BG9lgVoxvBfN+n949SPUF"
    "NSCE1BmC3h5/sKbDnMzJH0nASxgcMlMqDN++qWwW2l68u4hi5yLSZh7InazgvCJGKXcbGmNf8TvTl/O+5aMH6hfvP4AHBy29vY7K"
    "tx5ligv+g0L5bBqjGRBNDVChFDsNSfN+XPY+X/Qf5ZLlo23gHoZc2JzMyR8HlqfVQFRu7jLRyFsw9hKK5aNpjPkZ0qcZpXkRSX3Y"
    "N3f+X6rP+l0ba7MG4NapUNl8kinarxCXTqU5loFEU3xdsYZCCU2a/6POXcJlS34xAf45bTsnDzGt3AJh/4bHSlS6Qmz8UtIGqPNT"
    "fGM0o9gVkTZu8U13AdUlt+2vJt43gFt2+Xs2nGCy+NvEpSfRHM8QiaaYzIWiJcvqIO/0l575oTmNOydzOJ6qkc3aTW8D+z6iuEjS"
    "mB4zyih2RqSNn/oofSaXLN+2Pz6x2ecN0AcXbZhnsuhqih1PojHmdgNvqdOq97/wmp7jLz3zQ/QMWioabnwOvHPyUBURpVccFTX0"
    "DFp/6dKPeE3OU+9vpdRlUXWT/jaiMeYodjzJZNHVXLRhHvTRrv46CA0sDA4aenudDGz+rJS7X0lt11TNC+HUSMa3+ET+jOrZdzCo"
    "dnIDw5zMyZy04kg5Nga+/QgjnV+k2LmY+tjumrhjfqT1kat11ZJX5f6wZw9ZmT0DOHekTf9176Dj6Mupj6RAPFXzzrMktfU+qf0Z"
    "1ZU79wu8rZ7J6TI5ildRwyIk/PBwSw9sRQ80fP+QkMO5DnvqCz/in+m6iOrKjA8Nd5tx80Xi8koao1NBDCnl7pjajnf61Suu2FtQ"
    "S/YIsqFeF/Vff46P7HfyVr+8SBnw6uiYZzWpr9fm+POprhybjbKwOZmTh4S0g8Lrukyx41ri8nm5a2pb2hGxHmMxmfuTbPVZ39sT"
    "vmYAsAqVPqG7Z4Gpj15PXHwcaWMiaqbqKHZYsuQmP9L8E65Ycf9+g7dyc8HG4y9UYQHeeTChLUsiKy69zz3x9mvo7XW2f8OztVA+"
    "ibSRofbwdTCIU2wpEte4061a9pW8wuxI8tmFgymIyZ+DXbPxeVroeDhZ081aT3ZrvbWxw52y7YsPJHvFHymIF5hi53riwlNp1CaD"
    "2BOXDGnzl7487yxGhnZS7dPpmZxod5Ctt1Srmax5dh+d8x9HfWQiXaReiQqGLN3mx+sv5opz79+vnFULGN0jXVqTD9N19PEkjaDQ"
    "1UOxEx255za2Lvwq4BR7MZ1HP4PxnZNYEQ6DeAcd8/G7fv994CsMYYAjZENpq/VDZgyu7NW8HTKAUzH9dM5/GrURMGaWbstDsQMd"
    "TX/LXU/7cnjeKg+5FONQrwvYWbnTV254sZH0OqL44WSJhqIoMaSNjHL342R8V59Wq39D5byIKtmeAdwzaKmuzKKB4bO9tW+mPuYD"
    "/UCu1o1VwPi09kbWnvubAw5YJU6RaBf10YVkiQcMqMd7g8ikmmgdoz7qSGpu4vqHZZM7xFhg9MjbIXLoOlMYmVgH7Kwh2DsDsush"
    "b0r39rocQ7/21ev+0hRKX8VYH/p+REAs9TEvceHNdmD4c9mqs4enW7vRlBP7VJQrr4z9dv9eolJElvh2iaTiKXVarY9cTuXcr1BZ"
    "F9Er2YGvHxaRVtuVITQ/GHTyBhETTAlhmnM/y/il9fnmiNkUee7Qrtn8Yi11vI5kPEXFgoKJRbzb7o6NLuRNi2v7dBlaa4WAzBaA"
    "8/VGLXNCSDOti6is+Jr2b3iPlOdfQn3U5c9bUKdEpchn6Xu58spnsK1nisUyAeBW5cjAppdQ7FxBs9bSTuHULJQtjdEfaceJ/VTU"
    "0IejetiQ5fMcmdunB7e3jaX7NIcdgQTkyIlALxoKbWLGL6Jz/vPBh35rVYgK6Nj997Nt9CKgdohXcgfZbuJRQkP8nATpO8+BGu24"
    "vSr1bc+kUD6DpO4RMYgxNOuOYucK7nnyi6jKUDC9w96O2jDYulWprCsZ1UtQrznvT1sh4l0q1vwdf/+oOoODFuk9yE2f90YiPleB"
    "fpI+bPlonZS6LD6zmGgfZnkt/8jd/Dwolu1EHGcGe9JnllIXNGtdR9ymUFunPupo1lv16oqNBWUn5ewQ/U2BQsmGuOYenu2evRZL"
    "oQPGku455E6KSYSai7rv3/h3xrtvY4xt7+vADqJG9RJfWXctW9cnrQBlQEdesGEHnnW+FjrPIKn5tumq6ih2Wq2N/JuvLP/OgRRa"
    "7yaNcSHuLhEVDKomD2IZoiIk9dKkQOWw1keDE6970bCBL2s5YkstvoA2eL3WaY5fD5KFCOpMIMeBjRC9CQj54CNGvMldlUBXFJhQ"
    "5NBNYQE0o1m/HmE8rM8BPTaPVyPobZRG5nLvU/zhQUvvsu/pmo2flnL3X7Tzw4IlrXuKnWdY0fPdquo1LRwGAG/dqlTUKMNvzWmr"
    "tK0trTUktZ1q3EDQ1D16UCcMwKKRXf5n88/HZ0Vcg1AXkoKLwGiD6nlNALdq6er9/WjTv+k3RNFJE0ExPCYy+OQunzb/lOrKxn7f"
    "51wxx76MJ8Uawem4zxovo7ryjlkLuM0JLWyp0C/J+Euwdj7eaR7QUkRQ7Fup6LVs7ct94J5BS7XXMfDcxYg5l2ZdQQOLnOIpdFit"
    "j3yW1ef+JqD+EHyXoLl/up+7ZT/tss171hS1OAZtUkGo7k1NyFQTPmxWoQ9h0dAEI8iie5StPUpfTid6qKqsUhFuWST09MDW9fk1"
    "zlOGhuDUrTpT3m+fz2nregk/27znt9Sj8Dd9M1km+/u9ShGqQu+QYajHHzxw97TOM6zJ/p80ctAHxeR1J1+XA16Tg5Sq+FwL/1bX"
    "bP6MdHS+bSKgpYZmXRFzLvENp7OquoWeQRtNKEnfS2leTH20lfdVjLU0x2uK/hOotFB/ECd3iHZWtnQYm1ykxhyH1yynl1WsxOL9"
    "7T5rvjfQ0qrsv1+1aS+/uzffCBXYe8Rt4nv1DFpO7VFE9lh/SpXJnSb+wDbaJC6xajW8b4+VitVQetd33l6aQqb/vOJhpSKb9nJP"
    "9dDaWT0UlyHP4/f0AL0HtSsOk/Y9uJxyq2xUZB+Ur/uzJoeihbcqIBqZj0pz7C8wtgNtaWHNKHXF0hjtVdgSNPBQr+PKLbFsT15I"
    "mkArpaLqKXVYrY1ey2XLfxXSE4dIg9mdlKjJX0nXguNJmlMKORjZfhssfP+MoDpY6ZgfOIj6+miDZW8LWBXfzrGt/cFCxJ9sXPNk"
    "xB6H+gIq20RkmzO6FZG7aRV97HclWn6NVjL+PTeeYLNkkTp5DMY/nMCavV1i+Z1rcgu33H57AHrrGjP0VPcMWk5dKNxyjwYwDVkq"
    "mqGb9uzrdpuo/b5F5ykMwdb8M/a3HDYqhGd76ql60Gs1qJat6yfde36abV0obX7xgzkY3nhlzDOP8tCTn465Jr1rnnDV4nRGjdty"
    "ny751ny65z3COneqGjkGlWMQ7hDj73Uu28oT7v4dvZPXZJYryapVT8+g5V1n3aoDm66RUsfLqY/6PHZhSBPE6wv1yi2X8qbFaQQQ"
    "bW8u8XHxZLKmMpETNWQJxnC1QyUUtR+itAs5xvdRyPEAy6S+S3vFlgtw+mr1jfOJ4gXEpZyfWsBlqCrGJSNcvuU7IP/l3/mlzzHU"
    "6/a5mK1rvO1DRXP82a/BmJeQJsvUxl1EdqLizDtUHSZOE57+6O/z1OGveG1+ltXn3j5xWORAvlJje8/wp9TGj+MppYxbhwU9UYiG"
    "M8Q8imYNWgUYIoLPAI4ztflf46nzU1QNtw4reqJSjKw8tXybO/Xm19J7WvqAPO+fbzzJRKXP8NRHKrcO5798pKdYKEj/hptdtuwN"
    "YV32o1Ir/0yzdvMbiIt/ya2NBIYNnAhs9pS7izy6/mEPn20XIFXUtC2tyndPF1t4nRjzfNCTtFCcGKHiM1Q9xkvKLx61hYHha/14"
    "8gkuP+ceKhUz62Z1Tw8MIQb5jGbNlyOTMdlU4sLJ0fbmkgy+FwHijDxTCh0R2a6QchA8tmDIGre7tPi/IEqvzk6ARwlRtTBIZQ+F"
    "HA+gtPz6NdedIVHxPYo8g2IREg28vy2aoLBAwXcU201ceBFeXyRXvPAtmj7zYlav2LDHCH3PoKUqjv7vLjW24+PExaeChjlQLlGc"
    "BCLwYFGGqRXGFIiKyzDRMtOQi3Tt8FU6Mno573nWrtDRQkbjF0bRJZS6TiYZD+k+zaPwLg0vppCpgZEiUfHM8ON8z3mFQgmt7ToB"
    "7jn8RS19hDhL99fuYOSoEl0PezqNsVCumd+/UjwT2fgR4KZQo7CPnH4fyiK1/HzT24k7noQHTO7ii4Gsibf2xmCm9mn7EHnnVxdK"
    "x1FrxMgbKHbZwPOcQppMXXdVwZiYqLSEKFpiTP2v/cDwZaw6+5O5eybMFhFjLx5Qd/f93zHHzv8dUfFR+NSjealvoSNyLnkmcF3w"
    "dVWWkyXtyEEIXpWN1pJrqS6uhVP/CEy85yex6b/utdjSx4gLnTTGlLTpw6kn0+Y1aZguoU5DmSlIqWOJ+OI6+jf+re9d9rHdWBQq"
    "FUO117Hme88zUccg1pZpjLm8uslMuAs6LVOjkNR8zvB/lBS7LkHsBdq/+c2sXrKBSsWw404hLoyT1Dxp009YT6J5mk5miEdAmvvA"
    "7WCPePAGdHz/H5419Axa7rrf0DN4YNaZ4KmsN1z43CYDm64iqX2ctJm1U1xK7uulL1W4ad8aa9Ai4ujfuIyo+HjGd+ZxFBWQjGKn"
    "xWVf5l1LfzoxLVMca9Y/2cRdX6BQPpX6CDRGszY5+8Sjyw9tCdSvac2TisdGjzDFjn/VgU3L9ZTuv6JnUZpPH5kFEIvSM2j5yHOb"
    "OrD5GimU30Y99W2FlyWgshzQiPdef7w03ZNxKe3cbG4+C7pBAU5deOTNNMk1r1mz4VXE5X/DO2jWMsREudnpUQ35cBuFxgCXahih"
    "iGnnyRs1hzGWYtdHTf+GxK+W/9cGcWvkTPEFjzOafRqhTLM+teMEMcQli82rpQLbf7iOYBAxuEypjziJi6cJrGNg09v8qqX/QqXH"
    "wyhoPkuqtXm0nbrbczRWmdzUoPln7C8AFUnGcpfhIA/2ShhDmep/Gxr92OiYfGSJIBrhMhH0xfqhW/vpPaW5PxpOxL6YQikKgVjy"
    "Ih4ivDNi9LMAnPB8S+/ilDU3PMFE8nVsdAK1XSkiMa2CF9UwCshEpuU6tX8WqlcMWaJkqZeuo/6cn++IVXgNPUOGoVlqhskxJ2I2"
    "kDXfNik2ZXApovpkfe/1x0e24U9XY47CuTyopIqNDc36Ll/u/N9gnpx3GMsm/0A+b684BracjtF/wTnFZzrBNqLBhYiL0BwHl/4e"
    "JcJGx1AoWZJGzsCf12yr92RNJSr8E5ffsIV3yg/zclMQURnY/A5K846iPjLBaKKqxCVD1vAk9R8rch8QiXA8NnpCKF0dB3woqYOI"
    "pO4xkSUu/7Pp33yM7xj5AHXmUeq0JNgpPGkuDVMgp2NYBOKSZQr3vlriIown8/YOXBG8gmqn0fhT0r95PGzq/ca+V4kL4v1VbvVZ"
    "X+fKLTFvWrxd+zd9SQrlP58I1ojgmp6o+EQ7sv1cB99qFRvNGNUfEkdluFvUvYSkwaQ4jieKDUntNlca+1oesHJUtnQYST9H3HFC"
    "zu8W58uuGCsUOiw+g6R5H0IT9HhKXTY802a+7kZADeM7Myl3v0oGNl/vV/V+9GC4nWd2CQLm/Jj/rumo78IW5uNSDQeKAzFH2YY/"
    "PVKRUymWLY3xvOpDfBgylt3ORU/bni/ckZVo70NhXWS0+VHirs72d2+Bt9BhSOq/RdN/NKrDmUZ3ETkbJfpw52vPFZG3EhUXkDYm"
    "Wr9c5ih1dkh99IPaGiEh4hnY8nDR5AUkNc2BGK4RFw0u/ZFRfUuWJTe0oq76ng3zooSnumT8NWLMa7GFQpsATYxBfYKYAsI7GXfX"
    "qsh/SG3nE8X7pqqagDJ1KjwJGz85WA05WsWAuhrN2reANBzY+Qy+tBGp6u2cMM/lUwL2nP0RE1MoXaBygIaZeih2oWP3XQd8nW2l"
    "3NzTqzVtvn5SlZjg1VMqGu+SlwLf3GMB0SCGXjyxPouo/MiwJu3edSUuo2k6xEXnjzM2WKDam0j/xnfRseB06rumtcoWBXU1bdb+"
    "2QrXZMgd4JPYm+NdUluM9xdS7HgSSS3vj88bctKGR2QtVwx/kXfIHcFtOsSMTQtzly+5m4HNt2Ps/GChYFAfeOga9VMjVX1icPTa"
    "i+GJYqNJfeP0CO0R4/eKOLN280spdCyZCbyaJf+rwit515K7J3/xDG4DNuva4c8bddcQlx7XjqaLWJrjXgrlc83A9ee7VfINgMg1"
    "HueLpWPIEp2gEhXBZ85r4/V+9bk/oFIxVNZF3HKPcsny0Qw2ABu0ct2nTUn+mVLnaTTHM8BQ7i7QrP3Ai30tly25WeFHM+1sM7Dp"
    "byl0fJD6iAOiYFlZIfX3eNd46V7TNEcN2r2bxgpJ3bXLoPf3eBf1qBg8SfjBPR4Ql33ze2LOv0ni8tNy/zyYqUkDUV6olXUXU5Wd"
    "M3ZPhfJXFbSHKCaPBdjAamEsjdFEM/e5vHAlJdr4aDHRW0nGJ1O7+gBev82nzV4q52yc/HBSuBO4kcrw58XUPi2FjhdOgBhDljrK"
    "87qlMXahwkUsWjR7Uz+rVa/KsETRaUH7k4/qFFT1iQbRk3FZiH62ohwmQozcHP693hxBulfyCB+q+sY8wjyhHqKCIWn8Wke293Dp"
    "kruprIvaDJsVNQwOWq7cEnPp2bf4tPkyVGshUNTaU+JDftS/uv2pkS0Rl2SiaUOD1nZuDDv6Gypq2HFWzKJ7lFN7tH2dyrqI6ooN"
    "vjG2Upvj6ynPjyh0GK2NDvrmjmdx6Zk3h6KQimnfX0UNV26JqagBKe6h/lsoRfPCddROeW9FD2Stba4xW1mFfb+YkoEIVWeVdYFA"
    "AvNpbDRR2CEiuMxR7DjWRPEFgNC33u6+wcVT2XCCKM8hqYPk30HFUyyj3n+X6vKbGMQgogZ5JaXO+Tg3KeiHgHrfrL+ayjkbqQwW"
    "whqooVIx+R6IqJ49oknhFZo0fkJcNGiemRERskRF9aVc8a35YQBCZRZwc57Jj/ufYGLaXTuikmP25EiEE1BHYIxvaQcHeiQ2uVcE"
    "xJf6Nz46UZaRNiaGTylKVIJk5KNc8bz7eeOWmOridJoTqUDo37xsxY265rr/kY4Fr2yXu6la0qYoLKcy3E317BHJzJgm9TBONZyc"
    "gnpPoTzf+IWv91X5ANDkIzP4dpWbC1QX3aeV9X8GI/8lqt/V1UvXTOSDxYVqqurk4JzwpsWe/r1UYknDUxUfSiEP2j06mHZCn4/B"
    "1t18Pe/+29RH+7G2s13/q8FoUcxLgatniMUYwJvYvIBi5/xplDQSTiv9vMJEqSq8KFhDrXJhdZS6rDbGvkH13O8EoJJOix1ou0Ck"
    "urim/RvfJ6bj00iik2omPHHxJBynARu5ZdHsBX49IyF2Kq0skaAOEU6IUDkW76cGNNIGonpf+5Q8UqSnTxiqkmCXEseFULgSIndY"
    "a2mMjHnxXwKYVLGz+/fPzU9jiv+hqq9sm3UiEnKvPBrLY4AfZZ7fmCzdThQfj8tap74hbShR4f0yMPx88f4aj/wcY7ZRsnfwD4vv"
    "zUsdg6lZZafCM7Tl0oRa7D9gWk+gULYcuA/cmpNbnOLrBdP4tzqw+StS6OgNaTYiBENaR9Dz9Yotj0Lkd1PM6L4+R1+fMLC5d2Kp"
    "8kBsFBsaY9t9VrwWVKhKRv8NJ4J7HM5J2/wXBPUIdlABqnshqbjqTWFPFKNv0Ri7Dxs9rB05B8VGGJcs9rCxXQQ2G0/b2Ps0aZCn"
    "uHJQe1A5NsKYo0I2I9/IxghZkrqIuwEYGjpyFPBRN+ZcT/pEKZQhSzIgzisHAIkM5lP0b9r3BgavuAU0x2Eqs4liC2JJTnbwI6pn"
    "/V4HNn1ZCh1vyHm1J8y2tKlS7DiXqHCuaYyBzxo0/Bj9m3eA/kqNvVm8+5E3eiOXLvtZALN4btmXj3o4sSvgfVOb4/8iYu5XnEGN"
    "7t9bVTVpFqyYDR6gJydSGMo1qfGf0SztnZTPFrx3lOeVTaP2Yg//lJvRGZVKqKKqrDuNuHQuzfoEe4uIIy5H6rL/oLr4XiqDhXAY"
    "+sdj5Ch8NknBigmmNxeagU2v3yd5n4qSaATaMUF90zrmBfV6Sq4tDv1Z33KPAjjrtxmXJRhbQF1oC1UPxhwVoV4nFXDkJX06StPc"
    "FUyyHs+RkgW+/9ctU+MRuTshUyKkIiXi0oq9cQBMPujxPk/VTP+doJ5yKwio+v1+aYw8h1LXiTTG0jxVEgotkponqXtQi9gSxpQQ"
    "cwzGniI2+lO8xyTjIwxs+inGfs4zcjXvetZ9fxAaX80PeKSuWaNPqyt3HtDbJ4KBUyOteUOIaybfNhG/nBIczLWNqv+/qH4o9HAj"
    "wT+seolLPZS6DI3RFn9a6H9OG5l17vMZKhz9tTza7Y6jNJ9JDTsTEhWfPlG5tY91VyBrzkwkofm6z0rANceei7ZBMoIxx5C5iftT"
    "r9GU2xXJm741odQ5zpEmp4ZUhFHXqTM+fFXSerbfuzFYLWaacnYYaxE5PvxgKGJ17+1+zfoLTBp9jnL3aWHcZOIJVD4mjywq6hXn"
    "p/pdqoKNuonjs7CFs0yDv5XqhotcZfl//QG5uIVS59FU1o2F0suFB5ilWO+npVk0Z2hsMLDps8TFvkkAtiR1ROQs7d/0NFj2QwYH"
    "LT0rHUd/tSgj/kW4bPJh7CmUDI3aD7Kbt92AAn3l/Bn5jsDworobSrNmNjWouW/DdmrbooaabeH42fRUQhh8+zjRUUnOETeFKyea"
    "toElr+oTGvcduaRjatI92HhCXI4PqaTVe0OxE5qNnKZnoaeihsvkJ77y9XPFd79d4JVExceEQo4k0Nt6R84q4lrmQJ6eElwWCk1o"
    "eKLCY9TG/2kHNvW6VUuH/mBpvix1VFdms5LzZMJf9FL4D9MYvxgxZXzLXFRHR7eV+q6XKfwQTrUIjrXdZxIVn0JSn5z7BWOFSD7F"
    "UK9jaNDCwnx9bcqeSvrjYnTAPv2UkJ4zFDugWVswe/s0h2rxYTHOzYjHaAYtBEgHNn4YcG9o+j5CqGZOuNEC3lu2iTVTA1RiwPs6"
    "Se36A2usmPZ4BMf4zhL4X4Ug4D1Kr/h8pMYOhdX6vm9cQV1Xirrl4rKlwOOBbpAOih2WqGBxWTDP06ZO3CCGLMmwUaTIx6msu46q"
    "/H7WQPSHlKFelweofqZrNm6QctezaeZ0tiJCmiBqXqCVL1XpWVTPsymvJC6CS12+lz02tjTGd/i4GIKRW7cqixbl2Re2a3MclAiZ"
    "bCwrJI0tCLWDJrAXHOMjJZTrZy121MJe5o/FSGc45HVynTZRux63HaBwIHSBfTjw8xbL4REh20aD4+vlt6H3uZXawWMjg2/e78s8"
    "l79fWp+1a/b2+hbfNiBUbo656LRx4MsaXlBZ10WhcBJZdpxp1E9AayeocIqIriAuPh7vQj2u5LW9Weoodx1jVF7i4WMs6hOOhFrX"
    "nFDeGPmEqj57EsRC1D4uPdGahcucyLf4wKajpS7PyWMQE6nAQhGtZ1/mkjO2TQylDzlZp9xpXFrD2I5cu+dJGSui/iK3asn6WT2Q"
    "DlVa2LNyPGjnhGE2YbYbPHdibPD/QnmHp1AWA8fNWjTtj0XyqJ7x+mOSxqTKKA19llF8HIkuCQn8ddEkFTv9RbuIYrIfVFkXTfl3"
    "z2AIqgz1umhgw2L5wM3fNPHOVwDwoVuL7cKJ6soxLl12M5Vz/tevPvsz/rIl79HVS/7CLywsIs1ehcj9WKsTURPJvWNdErTM+iPj"
    "kO3p8aDiUvMNmrXbiAuWCcpfTxSrh1AkU/PPotjxaLLEtQEsCGmCgU9N1WQ5mYMr/ArYjo0mlwc7Sp140WcA8MYt8V7WPbymF7wM"
    "qt3XGNCDfCDk+/VY4rLkhSMSgokWPHdGauReEXPiJFMgFPJT7z6iNkc4FT1A5ru/b+zIbUSFk8jSvFpAPXHJSi19nVblO7xxi91j"
    "I3lFDaw3VKuZ9D/7ath0l8bj/bxj5a5QHJEHl4Z6Q5F9rJd6eLuIxJjCk1mzfiMXnvIL3rglbgdOKgi3DMlE59d5nm04X5WrpX/j"
    "eVLu/stJ/Eh5ybMee3C+Vcnszol1oAUdh9BOOHU9dEoQNWjNEenfdI1GhQvzvtzwfZOGiPJc/dBXizJqXjLR/5wHkeKyIan9yG3f"
    "tRm0XXWH0Or/renA5u+KLZxE2tR2513aRJCX69s3vZvua5t7Dg6qUBmKqUpi+jZeqB3zlms6uppeCSm+Q2FsnUla2FM3D1sAqU1E"
    "5sWgRu6NUG7DRE/Pq0qkTSmkeTTtSCrkaEc7T0t0YNPVEpVWkSY+kP5haIypRPErzNrhL7lLF/9n4L0atFMS8j095MR+3gwM/y3F"
    "jlcggjTt81i7uc+LfAFwDKq1t97wAhXtp9i1iOY4jO/MKJSPM3Re6ysbX0R18c+4Kj/Bh4ZaUfL8ea83eXN9gsr83VIWwWAaO4gn"
    "oDz2rvFD4sQSlLQ+emjthHsPZjmx/2bSxpsR4vyZGHymmOhhMnr0J0T9OaRNJiqqRLEWMF/gI89ttsd4TjNHjXP/rj571QSnNYas"
    "6Sl2PlaOHnuvrq6+rW1N5RZbe9239inVakL/xqXYYlUiO18Sc772b/5HjbIP0bvi/ll9Fi3siTl2Ul96eP4mErL0tgj4JdZCKpMa"
    "hlPUsDz4cEcY1WogDUM1ukoao28jiueRpa1op4JaRa42/Zvme/jkbifqEFD54QIpNP8BG10aivqdJyo+AWM/L+++4XXWuIFsK5s0"
    "cqvpetgiRu9rIlJATETa8MSlJ5jYbqJ/42q/485P0isz+dwewKzZ1Iu1LyQZn4i05oU/4nWL7umQlWnFFa1otjUPt7c+YqV745bv"
    "sKjbUBrx3LzdcPSfpvuMZrea2pWyRKV+BjbtRMUiB3MQiFf8R1m19M4p1VVDvaGPOj3zx6qbr5dSx3Iadd8eNeJTlULHq/JU3KQC"
    "JGtpjI94uq5up6qmxiIclYpxftl3TXPjBkrzzqXZamQRQ7PupNjxVvo3o5lWqC7dMcPBImbNhldh7EcQ5jO+M8NG86TQWZHG6Mvp"
    "33iFz5LPB3rkQ2HVbN1zWA8VWSGTCTcQj7UG+GUk8NPQ4Z+XaakaXIbAaVq5uUD1tASOoEh0tRrSOqvldgY2foBCxxrcrjC8vLXJ"
    "jS0Qlz5h1g7/BWs2/Y8XvRGJRizuRA/PEGk+h0LHY0MVlloQm3eKZDL/4ee7Xb+/laps8Gs2vdbUR75NFC8kS317s6QNj4mPIip9"
    "1Bx94l/p2s3XquerWLMdpymGMsY+XrL0ddjoRUEl5cTsLaMxaTjv5cvhUJphbdTZ3dfMg0QFVfNF86j054zcK4xIxkmPLjA+vNbD"
    "FxhUu9cawNBqWJRC+a8OLu2SG3reY2u1/8ngTnqHJk+FVBb1GXrFydpN/w6yAvEyqe9ACLXlE/OqEUexw2p99JusfvLtezRlb1kk"
    "DInz1eHVxiXrQ+ynzfhoadZVSp1vlWbtuTqw+T/VuU1Y7rTIw1TlLEUvIC6dGQp4moqYCO+U+khC19GnMLbj7xgpfmFqDuigJaz1"
    "oFr5+aYn56QC+TAEtYFwg59GRtxPfNpsYGwplGlBTn62MOL+0zMYpmfQHFHDu6vBlPZb579HGDlHyvOf2WZlEBG8C0UVhfISRJYY"
    "nUx0YUKzfBjIPGkT4Sl2FXTnXddp1ry4lfuVNRv+XKPiV7CxxaUTJ75LFZ95CqXTxJjTxPt3ktSbiNRR7SbqMEQFaNZoT1UIrl5G"
    "59Gxju/4NH1LfwLT8sAtDmthx+6UOjmxnZgSUfGp4WDIoNQF4yPHtf2uRfs6rBWS2sHNRgpEwgI4iQvZHmI3ga2D0pdMY+xuosJx"
    "bSspd8Cn9ZgYXCZG9Wq3r8hwz6ClcvZ19G+s0Lmgn9pIimqU0+gIjZojLpwsNrpYJq17IApRSOqhCWTy0L8oLlIf2eGNvpwPLqvP"
    "Sm6+okJVNP7Z9U9zxizMs0Pk1oaQNhtG/E9Mlm77MWJun2jlEkE1o9wd+ygOZvQRR6kjSk+Pp3paosKraIxuoaM7BjJQ356cmNQd"
    "zZoL5Y41T1J3NMYdWbM1eiY3u8kozYtI6r/QzL8sTIPog8FB6y5b/lWfNl+K4X5KnTYf2ta6RhiZ0ag50rrHmCLGLAAxNMZdnged"
    "bN5nlOfH1Ed+opm8fWaihfPC5hczTH0sRUzrHicOdvVKWvekdY9Lmzn31oEyUe5/G+GUlkKdaC30mezBVA+xiktPv0cx11Ios+fm"
    "DfVERUNS+4Wbv/BrwfTcC9H8YI+nsi7y2TffreM7/4XyvBhjNF+XMCwva4Y1aa97zYd9UG/RKbXuOyMuWlRTn6Wv5dJlN+cEhrPg"
    "doY2XoeeR7m7gPqsPaHBRiDm9izd9mNDtTdRdJiowKSQveBSFP+c0Mmxcja1bzbzSw/yGpLt+TP36s8plYrh0iV3+2TXBVof/TLl"
    "eRFRwUyajij5aW/ylFO++fI2NFWPjYRyd6SNse/6cbeS6vJtbQ7t1vzXyvL/8vXaM3Hp9+notkTx5Gvk5HZiQimlC4Gs0J5oUMLf"
    "2UjoWBBpY/x67+UCqkt3tPthp1gX4lE1XLrkx+qyf6PzKJt3/LiJ5yIu9Ce3XnjMDA0JU95zGF7G71OHq9F/I6kHs3FPQbmoAGI+"
    "w4WnNIMLsJeIuoiGtsQ+1dXL3qz1sQGMNZQ6WymrbMqaTF571WDqa+jlozwvUvR3vtl8Npct+3IIRs6SpVo9z6EqKnp+KBXVCUsv"
    "KqDoMNXexORWzffyTdn6ozy0rudw+YbHQB6GP1QpWAGOoWN+RLm7MOW/8LCDDCwvnPnz5BhqseyXP1w9f7uuWvJ8ktqbUG6l2Gko"
    "z7PYeIKaJZDchY1hY0O5y1LqNMA2mmN/r+nX/4R3L71zN/OpV4LZVj33B/7O7StojP8NqrdSKIdrREUzoWGlNbIlvKJYKHVayl0W"
    "5G6tj1Y1/e05rD7z9n1UX4UssUv+Rsd3fBxjoNRlKXdHdMyf+ip1lOk8KkJ9xwyfczQdCyLK84q7ve/gX3FYp3lFdRLvOYDTG+bg"
    "Pn7JMGk6TLFDZoh4K2ItjdEkEj+0x3jATCAGqFSMrjp7tSTJc3Dp+rCu8yLi0qQ1Ia9ZV8VGgS+rPM8CTa2P/6uO7FxKdcX6Ns/a"
    "bEggZFAu3/xYETmXtA4TpHatPufvQV5K6TX6hmmMjGCjblwWTDbvHeXu2NTHX+bh3blKPzTTwI82Vbs/SW3XsWSpoj4MV0kTAe7M"
    "KVYODL4i/4/armMmPs8EHwG9h0cem+z7pMsb20XUv/PMq7joi583C47vVdXnierTEHMScUFoEUhlCbj0t6ruZvH6db+j/gX+ceW9"
    "rQ0xo/k01OtyYDc9fITKV//dFI++QH39hQJPQXkccTGe4rO6DLJ0G97/CJHveD/yeVY9886J6+yldHLCtG4o/LWtbvis9+7Zqpw0"
    "wwN02J3WqL+pbYJv7WvZYZ/X2s7H0xj3uzVtHLT3YsI6Id567s4gzByacSOvt/SuzFi7aRAbnb0bV5eqp1S22hz7dnLpsp/l67if"
    "eyhPo1UqxlWWfQP4ph3Y/BxfT18iylkIpxAXCxORdw8u207a/JmSblT4NKvyFs8W7/esScCacfRS7iqE/L+ECZM2sjRGRrxG38iV"
    "b9i8ZmDTNyh2PotmrcUp5IlLhqR+i8+K/4e+M+p5LurInSQ3PXf4jusfRjcPw7su6+WRzugdGDtG0+6guvjeCb9K7f7NSJo0F6kl"
    "F22YRzfHotECi3s4GIN1ow65i4QdVJdtn7jOoA3+3X6vQc5q8SBds9ZBdcXwI03mf4iZRD3bMicLJSNJPW/smLZ++yvTCzf+/hud"
    "LOg8njguWe8fLY6RTLkP53ZRXb5tiqacnUF3U/eIAh/+WsGMLLiRQmkRaaNV7uwodhia49/yq5aej6pE7QZp7OdBnj1xyuXpjmLn"
    "qUZrz/Mig5Mngx8SSE6YJ9w46WdnEOqUD+bhz+bntQarDWLYilKV+4D7QjCBH+y2uRb1CT34/WfHEKVKFgpEhoJG610+CoG+yM2c"
    "tglcUGGY1oE++1Bt1Kocu2vezC7FGcC2M9xu1sNMz3Y25aozsr0eRtW+QBdU/9o2jc7fJm0A58HDqGBo1u5wWfK1tt94MBLAK/QM"
    "Gk5dKFRXjgO/ytdk64x7jvU+n3M1u9IzZJBeZ9du/FMtlBdNIvlrFe9IwCrQt95Ku7th7Q+OMb7xY6LCcYGKtDXGoWxo1oZ9tmR5"
    "OwXzUJnn2hp8BYQyx5zadDZP3enXaMmpPQp9raFsD835ublmtGuHV6qJvpPvy4kIcHlepLWRD+jqpf8wq73RM61Jez0O43hRVKgg"
    "nHCjNduT6yiWzyRp5BYxHhsLWXK3N6WncOnp96JKNFF/evo9OrD50xKXLibLywvBktQ8hfISK5tf4lYtHZoVLfygyTbJzOCpPgDX"
    "mJOJA1P9G6a0DQZmEEuz1lSxn33A1n3WF396imvI0NvrzNrNvRTLZwWmlpwmKB8EoC79NJeefg+DYZxMUM1btyqoaJr+K83aaD5K"
    "ZFLni6qqrKGyroutPXp4Oi/mZE6mRGLDyM/LN5+kyPOnTVr0xCVRl97AqrNuCtMZHuSFRqrC1q3KFVvmo7IG73VSu3KIgDdro5qm"
    "/xpmdW/VidB0terpGTJUz7lVXfo5Ch2GCeqC4AuXu54oJr6Yqvjd+HnnZE5mXUIhg8n0NZTmdeGda5vPOd2sYD4FhJjFg1361luq"
    "VS9J812UOh8/QeIeTBAKHUZd+jmq59wasBqyEGaqz4VoJO+nOT5GFMkk1i5Ds+alULyY/uuWU12ZMTg4B+I5OVzqSKie53jfTZ2g"
    "ryJL2qzlOWWspTF+l7fmS4C22S0frDKYEz4MDJ8tceFCmrXWKNFwWkWR0Bwf00jeP8W1mALgqnh6Bg3vWvpL9e6DFDqmMs+rA2OL"
    "RuxVvOen81rN13ObbU4Oiy+IKEnjWRTKjydrurYmgoyoqArX8K6z7stHi+qD+rDaulWpDHcb/Ccwtog6Jmrfc+3r3Qd519Jf0jM4"
    "pdZgGrNAj6eiRuPCB6iP3kpcnmRKiyFpOErzniTpfR8LpYhzpvScHAbp6VEGB614/3cUOsBGEVHREBUNcTFGnVijnwWVBz1hTCU3"
    "nSP/MUrzFpE03CSmmEBSUB+9VePCB8I4nKl13tMoUUW5ZUh4x+Jd4vQfdhtYHAZ4ZVLsfrXp33Qx1ZUZ6zSa23FzMovBq0DYvvX4"
    "x4qYhdR2/hKX/oos+RVp8xeI/FqbtWuypHk9CrPKgPFAyzqNqK7MTP+Gi6XU9ap81OkkpSiKIOL0H3jH4l3cMrTbcLeZTeB8cr2s"
    "2fRx6Zz/ZuojGS0GyxBAcBSKlubY6/zqFf9+0BUwczInewTyuhJHlwvsqPs2LSz3AHUDj2rkfeoPXnnjlpirFqdmzYbXUer8FEnT"
    "oX7yuJqMcnek47v+WS9b+pYWJqd/zMwAbqWJ+rZ2Sjy2UQqlp5DU3JSclLGBwiSpv9pftuJzcyCekznZ78MpaN41G19GofRZXCZ4"
    "JxO18OoodFhNGj/WtGsZfYvG2xbyNJk5/C6i9CFUTxtTn74Cl+4MnTmTglo+E5wTCuXPmv5Nf5GTfEdzOeI5mb34jkoIlE56tX/2"
    "IP0+bfBueB2F0tW41EwDr8fGBpfuVJ++guppY/QhewrU7Tl/VhXP4KDlshVbpVH/czAesdpuqRMjbb7iQvkTZmD4nVSrGSKa06nO"
    "yZwcmojkZYuTXu2fPcikFS2vrsxYs+kiip2fwqWC95MjzopYBeOlUf9zLluxNaSY9txhte+TrHVi9F/315QXfJTGuEO9mXJRYzyF"
    "DqvNsc/omLuQK1bcT2VdlBfgz5UJzslD24royzvQKusWSFx8rxQ730DScHg3FUdiPKVOS33nW/3qFR/bH7d0/0yR3IE2A5sqFLv6"
    "aNamgjjMU/KU5xmSxk0+bb6FyvLN4b0H3AI3J3NyJCBXWrXNAPRvXm6s/SiF8lNpjOZVVi345OAtdliaY31+1dLqnoJWBwfg0KMo"
    "iHjTv+kySp1VknogfmvnrADIiEsRLqsr7gNqovfzjsW72kDu6fFzGnlOHlLArQx3S8FfLBL/A9YWSRpuaqpIPWKEQllojFf86qVr"
    "Avvk/nX97X8wQFXoHTIM9TozsOmvsPHHUWSCaXHKDYUJffWxWxFd69M7vkC1N2mb5LuPl5yTOXlQe+tUKmFmccvkrdxcMIXRXryu"
    "ptR1CkkN1PspCk/VYePAq+3St/hVS/+FnkEb5gLvn6KTAz5degKI7drNL1axnyQqzCepTR2Y3OISiosWMZA1b0Dkw75Zu4bqyrEp"
    "/jXneapzLXVz8mAErUoYsTPJT618qcMUj30JyluJimeiHtKmy0nyJvMBZRQ6IrJkl6h7vbt0yX+HnuYDczcPLhzfcq7XXLdIouKn"
    "pdh5OvURnzMnmynaGAglmUDW/CleP+etfoF3Lf3ljL52ax7MLfcop/bo7FOWzMmcHIDCqvQJtyyamFm16Dyd0TftH36MQV+JMb3E"
    "xSejSmDTYAZMCJS7jTbHf6BZ8zVctmLrwdZRHHw+rcV+f8m35kt397vFRG9BBNL6dMLzCSBHJUMUQ2MsUVgvRr5lM/e/qZu/9UFf"
    "WTMnDy2p3FyI4pGneThXkWcLeg6leQVcSuCw2g24GgbolS2qqM8+riMj7+I9z9p1KEPRDi0hPolC1Q5seKHawhUUOp5IYxy8m8ls"
    "8KgoRiyFMpgIartSlHtV+LGIbER1O8hOb2Q7Tn9PNLadZrRrrsprTh5QGRy0bF04Dxsfh8gjDByHyHz18nBElwichshCyt1RDlrw"
    "3uX9A9OAi8dYS6kTktrPxCXvcKuWXzMdQw88gKf5xVz0xXly1CMvFtG/IS510xzPv1Q+6WDSmwgUtYpIhInARuTk8oG6NakDjKE6"
    "DjSRhwiNz5z8sbi4BtUiSCci8yiUwv5UDaN1XBZGEKlmOY7MNDz5NvVPsRPSxoiqfFjvv+O9vO9Fowfj7x4mAE/yX1u+wZoNT5Ao"
    "frsgr6RQ7iJtgMvCFw0DmmTaCUXO55t/GQ1s+MaE8muZq86ckz+EC5zzQXsHgTS0PUw5T/UwZXOGGVZhH9soIi5BUh9T9GrN0g9y"
    "2fKf74aVQ46kze4Xnqg6AVi78Yki8V8KvIxC+RF4F7Srd1nOhpnXtc6EUNWJxzUXxJqTPxiIZTegTkG4aA5cxdiIqADGQlK/U+EL"
    "quknuDQngD8M1YmHR7VV1LBoSNqO+XuvP940/HOw8kpEFlPsWoD6HMwZeN8aX2Fok6fMqd05+SNTxzkjdT5PymCMweSunxhoju1E"
    "dQtOr/Yl83UuPuv3E/50j87O0LMHAsB7AjLA5TecbLJspYpZKejZwPFEhU6iQu5XuMlmy5zMyR+HmHzGnbEhXpMlkCXjwO8VGRb1"
    "63wUreOdZ/56aiDs8AD3gQFwG8j5FIOtfTqlAutDtxbZteM0Y/zTFZ6IyuNAT5Iw6OwRu8+3nZM5+YMoXwXuVLgP5DZEfynwM+/N"
    "D5l/9M1ceEpzn3v9MMn/B8qw8vt+j9WzAAAAAElFTkSuQmCC"
)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,image/*,*/*;q=0.8",
}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg", ".avif", ".ico", ".tiff"}


# --------------------------------------------------------------------------
# Download logic
# --------------------------------------------------------------------------

def pick_from_srcset(srcset):
    """Return the largest candidate URL from a srcset attribute."""
    best_url, best_size = None, -1.0
    for part in srcset.split(","):
        bits = part.strip().split()
        if not bits:
            continue
        size = 0.0
        if len(bits) > 1:
            m = re.match(r"(\d+(?:\.\d+)?)[wx]", bits[1])
            if m:
                size = float(m.group(1))
        if size >= best_size:
            best_url, best_size = bits[0], size
    return best_url


# Attributes that sites use to hold the full-size version of a gallery photo
GALLERY_ATTRS = (
    "data-lightbox-src", "data-large", "data-large-src", "data-zoom-image",
    "data-full", "data-fullsrc", "data-full-src", "data-original-src",
    "data-highres", "data-image-url",
)
# Attributes that hold ordinary / lazy-loaded images
IMG_ATTRS = ("src", "data-src", "data-original", "data-lazy-src", "lazy-src", "data-lazy")


class ImageParser(HTMLParser):
    """Collects image URLs from a page's HTML.

    gallery = full-size photos (lightbox / zoom attributes, on any tag)
    other   = every other image reference (img tags, thumbnails, meta, links)
    """

    def __init__(self):
        super().__init__()
        self.gallery = []
        self.other = []

    def handle_starttag(self, tag, attrs):
        a = {k: v for k, v in attrs if v}

        for key in GALLERY_ATTRS:
            if a.get(key):
                self.gallery.append(a[key])

        if tag == "img":
            for key in IMG_ATTRS:
                if a.get(key):
                    self.other.append(a[key])
            for key in ("srcset", "data-srcset"):
                if a.get(key):
                    best = pick_from_srcset(a[key])
                    if best:
                        self.other.append(best)
        elif tag == "source" and a.get("srcset"):
            best = pick_from_srcset(a["srcset"])
            if best:
                self.other.append(best)
        elif tag == "meta":
            if (a.get("property") in ("og:image", "twitter:image")
                    or a.get("name") == "twitter:image") and a.get("content"):
                self.other.append(a["content"])
        elif tag == "a" and a.get("href"):
            ext = os.path.splitext(urlparse(a["href"]).path)[1].lower()
            if ext in IMAGE_EXTS:
                self.other.append(a["href"])


def normalize_url(url):
    """Some image CDNs serve a resized copy at /<id>/<size> and the original at /<id>.
    Rewrite resized links to the original so thumbnails don't duplicate full photos."""
    p = urlparse(url)
    if p.netloc.endswith("prop24.com"):
        m = re.match(r"^/(\d{6,})/[A-Za-z]+\d+x\d+$", p.path)
        if m:
            return f"{p.scheme}://{p.netloc}/{m.group(1)}"
    return url


def _resolve(raw_urls, base_url, seen):
    out = []
    for u in raw_urls:
        u = u.strip()
        if not u or u.startswith("data:"):
            continue
        full = normalize_url(urljoin(base_url, u))
        if full not in seen:
            seen.add(full)
            out.append(full)
    return out


def extract_image_urls(html, base_url, gallery_only=True):
    parser = ImageParser()
    parser.feed(html)
    seen = set()
    gallery = _resolve(parser.gallery, base_url, seen)
    other = _resolve(parser.other, base_url, seen)
    # If the page has a photo gallery, "gallery only" skips logos, icons, avatars
    if gallery_only and gallery:
        return gallery
    return gallery + other


def fetch(url, referer=None, timeout=20):
    headers = dict(HEADERS)
    if referer:
        headers["Referer"] = referer
    with urlopen(Request(url, headers=headers), timeout=timeout) as resp:
        data = resp.read()
        ctype = resp.headers.get("Content-Type", "")
        charset = resp.headers.get_content_charset() or "utf-8"
        return resp.geturl(), ctype, data, charset


def make_filename(url, ctype, folder):
    name = os.path.basename(unquote(urlparse(url).path)) or "image"
    name = re.sub(r"[^\w.\-]+", "_", name)
    stem, ext = os.path.splitext(name)
    if ext.lower() not in IMAGE_EXTS:
        guessed = mimetypes.guess_extension(ctype.split(";")[0].strip()) or ".jpg"
        ext = ".jpg" if guessed == ".jpe" else guessed
    candidate = f"{stem}{ext}"
    i = 1
    while os.path.exists(os.path.join(folder, candidate)):
        candidate = f"{stem}_{i}{ext}"
        i += 1
    return candidate


def run_download(page_url, base_dir, min_kb, gallery_only, q, stop_event):
    """Runs in a background thread; reports back through the queue."""
    try:
        q.put(("status", "Fetching page..."))
        q.put(("log", f"Fetching {page_url}"))
        final_url, ctype, data, charset = fetch(page_url)

        if ctype.startswith("image/"):
            urls = [final_url]
        else:
            urls = extract_image_urls(
                data.decode(charset, errors="replace"), final_url, gallery_only)

        if not urls:
            q.put(("log", "No images found on that page."))
            q.put(("done", 0, 0, 0, None, False))
            return

        parts = urlparse(final_url)
        name = parts.netloc.replace(":", "_") or "images"
        last = os.path.basename(parts.path.rstrip("/"))
        if last and not os.path.splitext(last)[1]:
            name += "_" + re.sub(r"[^\w\-]+", "_", last)
        folder = os.path.join(base_dir, name)
        os.makedirs(folder, exist_ok=True)
        q.put(("log", f"Found {len(urls)} image(s). Saving to {folder}\n"))

        saved = skipped = failed = 0
        stopped = False
        for i, url in enumerate(urls, 1):
            if stop_event.is_set():
                stopped = True
                q.put(("log", "Stopped."))
                break
            try:
                _, ictype, idata, _ = fetch(url, referer=page_url)
                if not ictype.startswith("image/") or len(idata) < min_kb * 1024:
                    skipped += 1
                else:
                    filename = make_filename(url, ictype, folder)
                    with open(os.path.join(folder, filename), "wb") as f:
                        f.write(idata)
                    saved += 1
                    q.put(("log", f"Saved {filename}"))
            except Exception as e:
                failed += 1
                q.put(("log", f"Failed: {url} ({e})"))
            q.put(("progress", i, len(urls)))

        q.put(("done", saved, skipped, failed, folder, stopped))
    except Exception as e:
        q.put(("error", f"Could not fetch the page: {e}"))


# --------------------------------------------------------------------------
# GUI
# --------------------------------------------------------------------------

class App:
    def __init__(self, root):
        self.root = root
        root.title(APP_TITLE)
        try:
            self.icon_img = tk.PhotoImage(data=ICON_B64)
            root.iconphoto(True, self.icon_img)
        except tk.TclError:
            pass
        root.geometry("700x560")
        root.minsize(580, 460)

        self.q = queue.Queue()
        self.stop_event = threading.Event()
        self.last_folder = None
        self.about_win = None
        self.logo_img = None
        self.icon_img = None

        self.url_var = tk.StringVar()
        self.folder_var = tk.StringVar(value=str(Path.home() / "Downloads" / "iTestEye Images"))
        self.min_kb_var = tk.StringVar(value="5")
        self.gallery_only_var = tk.BooleanVar(value=True)
        self.status_var = tk.StringVar(value="Ready")

        main = ttk.Frame(root, padding=16)
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)
        main.rowconfigure(10, weight=1)

        ttk.Label(main, text=APP_TITLE, font=("Segoe UI", 16, "bold")).grid(
            row=0, column=0, sticky="w")
        ttk.Button(main, text="About", command=self.show_about).grid(
            row=0, column=1, sticky="e", padx=(8, 0))
        ttk.Label(main, text="Paste a web page address to download every image on it.").grid(
            row=1, column=0, columnspan=2, sticky="w")

        ttk.Label(main, text="Page URL").grid(row=2, column=0, sticky="w", pady=(14, 2))
        self.url_entry = ttk.Entry(main, textvariable=self.url_var)
        self.url_entry.grid(row=3, column=0, sticky="ew")
        ttk.Button(main, text="Paste", command=self.paste).grid(row=3, column=1, padx=(8, 0))

        ttk.Label(main, text="Save to").grid(row=4, column=0, sticky="w", pady=(10, 2))
        ttk.Entry(main, textvariable=self.folder_var).grid(row=5, column=0, sticky="ew")
        ttk.Button(main, text="Browse...", command=self.browse).grid(row=5, column=1, padx=(8, 0))

        opts = ttk.Frame(main)
        opts.grid(row=6, column=0, columnspan=2, sticky="w", pady=(10, 0))
        ttk.Label(opts, text="Skip images smaller than").pack(side="left")
        ttk.Spinbox(opts, from_=0, to=10000, width=6, textvariable=self.min_kb_var).pack(
            side="left", padx=6)
        ttk.Label(opts, text="KB").pack(side="left")
        ttk.Checkbutton(
            opts, text="Gallery photos only (skip logos, icons, thumbnails)",
            variable=self.gallery_only_var,
        ).pack(side="left", padx=(20, 0))

        btns = ttk.Frame(main)
        btns.grid(row=7, column=0, columnspan=2, sticky="w", pady=(14, 0))
        self.start_btn = ttk.Button(btns, text="Download", command=self.start)
        self.start_btn.pack(side="left")
        self.stop_btn = ttk.Button(btns, text="Stop", command=self.stop, state="disabled")
        self.stop_btn.pack(side="left", padx=8)
        self.open_btn = ttk.Button(btns, text="Open folder", command=self.open_folder,
                                   state="disabled")
        self.open_btn.pack(side="left")

        self.progress = ttk.Progressbar(main, mode="determinate")
        self.progress.grid(row=8, column=0, columnspan=2, sticky="ew", pady=(14, 0))
        ttk.Label(main, textvariable=self.status_var).grid(
            row=9, column=0, columnspan=2, sticky="w", pady=(4, 8))

        log_frame = ttk.Frame(main)
        log_frame.grid(row=10, column=0, columnspan=2, sticky="nsew")
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        self.log_box = tk.Text(log_frame, height=10, wrap="word", state="disabled")
        self.log_box.grid(row=0, column=0, sticky="nsew")
        sb = ttk.Scrollbar(log_frame, command=self.log_box.yview)
        sb.grid(row=0, column=1, sticky="ns")
        self.log_box.configure(yscrollcommand=sb.set)

        self.url_entry.focus_set()
        root.bind("<Return>", lambda e: self.start())
        self.poll()

    # ---- helpers ----
    def log(self, text):
        self.log_box.configure(state="normal")
        self.log_box.insert("end", text + "\n")
        self.log_box.see("end")
        self.log_box.configure(state="disabled")

    def clear_log(self):
        self.log_box.configure(state="normal")
        self.log_box.delete("1.0", "end")
        self.log_box.configure(state="disabled")

    def set_running(self, running):
        self.start_btn.configure(state="disabled" if running else "normal")
        self.stop_btn.configure(state="normal" if running else "disabled")

    # ---- button actions ----
    def paste(self):
        try:
            text = self.root.clipboard_get().strip()
        except tk.TclError:
            return
        self.url_var.set(text)
        self.url_entry.focus_set()

    def browse(self):
        folder = filedialog.askdirectory(initialdir=self.folder_var.get() or str(Path.home()))
        if folder:
            self.folder_var.set(folder)

    def open_folder(self):
        if not self.last_folder or not os.path.isdir(self.last_folder):
            return
        if sys.platform.startswith("win"):
            os.startfile(self.last_folder)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", self.last_folder])
        else:
            subprocess.Popen(["xdg-open", self.last_folder])

    def stop(self):
        self.stop_event.set()
        self.status_var.set("Stopping...")

    def start(self):
        if str(self.start_btn["state"]) == "disabled":
            return
        url = self.url_var.get().strip()
        if not url:
            messagebox.showwarning(APP_TITLE, "Please paste a URL first.")
            return
        if not re.match(r"^https?://", url, re.I):
            url = "https://" + url
            self.url_var.set(url)
        try:
            min_kb = float(self.min_kb_var.get() or 0)
        except ValueError:
            messagebox.showwarning(APP_TITLE, "Minimum size must be a number.")
            return
        base = self.folder_var.get().strip()
        if not base:
            messagebox.showwarning(APP_TITLE, "Please choose a folder to save to.")
            return

        self.stop_event.clear()
        self.clear_log()
        self.progress.configure(value=0, maximum=1)
        self.open_btn.configure(state="disabled")
        self.set_running(True)
        threading.Thread(
            target=run_download,
            args=(url, base, min_kb, self.gallery_only_var.get(), self.q, self.stop_event),
            daemon=True,
        ).start()

    # ---- About window ----
    def _link(self, parent, text, url):
        lbl = tk.Label(parent, text=text, font=("Segoe UI", 10, "underline"),
                       fg="#0a66c2", bg="white", cursor="hand2")
        lbl.pack(pady=2)
        lbl.bind("<Button-1>", lambda e: webbrowser.open(url))

    def show_about(self):
        if self.about_win is not None and self.about_win.winfo_exists():
            self.about_win.lift()
            self.about_win.focus_set()
            return
        win = tk.Toplevel(self.root)
        self.about_win = win
        win.title("About " + APP_TITLE)
        win.configure(bg="white", padx=36, pady=26)
        win.resizable(False, False)
        win.transient(self.root)

        try:
            self.logo_img = tk.PhotoImage(data=LOGO_B64)
            tk.Label(win, image=self.logo_img, bg="white").pack(pady=(0, 14))
        except tk.TclError:
            pass  # logo is optional; the text below still shows

        tk.Label(win, text=APP_NAME, font=("Segoe UI", 14, "bold"),
                 bg="white", fg="#14212b").pack()
        tk.Label(win, text="Version " + APP_VERSION, font=("Segoe UI", 9),
                 bg="white", fg="#4a5a66").pack(pady=(2, 14))
        self._link(win, "itesteye.com", WEBSITE_URL)
        self._link(win, CONTACT_EMAIL, "mailto:" + CONTACT_EMAIL)
        ttk.Button(win, text="Close", command=win.destroy).pack(pady=(22, 0))
        win.bind("<Escape>", lambda e: win.destroy())

        # centre it over the main window
        win.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - win.winfo_width()) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - win.winfo_height()) // 3
        win.geometry(f"+{max(x, 0)}+{max(y, 0)}")
        win.focus_set()

    # ---- queue polling (keeps the UI responsive) ----
    def poll(self):
        try:
            while True:
                msg = self.q.get_nowait()
                kind = msg[0]
                if kind == "log":
                    self.log(msg[1])
                elif kind == "status":
                    self.status_var.set(msg[1])
                elif kind == "progress":
                    _, i, total = msg
                    self.progress.configure(maximum=total, value=i)
                    self.status_var.set(f"Downloading {i} of {total}")
                elif kind == "error":
                    self.log(msg[1])
                    self.status_var.set("Failed")
                    self.set_running(False)
                    messagebox.showerror(APP_TITLE, msg[1])
                elif kind == "done":
                    _, saved, skipped, failed, folder, stopped = msg
                    label = "Stopped" if stopped else "Done"
                    self.status_var.set(
                        f"{label}: {saved} saved, {skipped} skipped, {failed} failed")
                    self.last_folder = folder
                    if folder and saved:
                        self.open_btn.configure(state="normal")
                    self.set_running(False)
        except queue.Empty:
            pass
        self.root.after(100, self.poll)


def main():
    try:  # sharper text on Windows high-DPI screens
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    try:  # lets Windows show our icon in the taskbar instead of Python's
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("iTestEye.ITEImageDownloader")
    except Exception:
        pass
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
